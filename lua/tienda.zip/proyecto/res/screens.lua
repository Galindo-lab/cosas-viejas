ui.create_screen("menu",{
"                   Acciones                           Misc.",
"[1|Crear] [2|Buscar] [3|Listar] [4|Eliminar] | [0|Salir] [h|Ayuda]",
})

ui.create_screen("SeeU",{
"Adio shula :)",
"presione cualquier tecla para continuar...",
})

ui.create_screen("listar",{
"Listar elementos de la tabla"
})

ui.create_screen("presentacion",{
		    "Proyecto creado por:",
		    "Cinthia, Aldo, Galindo",
})
