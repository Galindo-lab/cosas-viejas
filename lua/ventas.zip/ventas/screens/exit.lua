return table.concat(
   {
      "    ____                                   ",
      "   /  __\\        GRACIAS POR PROBAR",
      "   \\( oo         NUESTRO PROYECTO !!!",
      "   _\\_o/        ",
      "  / \\|/ \\      ",
      " / / __\\ \\___  ",
      " \\ \\|   |__/_)                           ",
      "  \\/_)  |       proyecto presentado por:    ",
      "   ||___|                                       ",
      "   | | |          * Sánchez Millán Mónica Ayelen.",
      "   | | |          * Valenzuela Ayón Aldo Javier. ",
      "   |_|_|          * Galindo Amaya Luis Eduardo. ",
      "   [__)_)                                  ",
   },"\n")

       	   
--[[
Sánchez Millán Mónica Ayelen Matrícula: 01276143
Galindo Amaya Luis Eduardo.  Matrícula: 01274895
Valenzuela Ayón Aldo Javier. Matrícula: 01275742
]]
