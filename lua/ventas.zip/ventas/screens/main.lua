return table.concat(
   {
      "                   Acciones                           Misc.",
      "[1|Crear] [2|Buscar] [3|Listar] [4|Eliminar] | [0|Salir] [h|Ayuda]"
   },"\n")
